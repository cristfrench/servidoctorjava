package com.maxmind.geoip;

public class Region
{
  public String countryCode;
  public String countryName;
  public String region;
}


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.maxmind.geoip.Region
 * JD-Core Version:    0.7.0.1
 */