/*   1:    */ package com.servidoctor.parametros.controller;
/*   2:    */ 
/*   3:    */ import org.apache.struts.validator.ValidatorForm;
/*   4:    */ 
/*   5:    */ public class VacunasForm
/*   6:    */   extends ValidatorForm
/*   7:    */ {
/*   8: 15 */   private String vac_cod = "0";
/*   9: 16 */   private String vac_des = "";
/*  10: 17 */   private String vac_edad_mes1 = "0";
/*  11: 18 */   private String vac_edad_mes2 = "0";
/*  12: 19 */   private String vac_edad_mes3 = "0";
/*  13: 20 */   private String vac_edad_mes4 = "0";
/*  14: 21 */   private String vac_edad_mes5 = "0";
/*  15: 22 */   private String vac_edad_mes6 = "0";
/*  16: 23 */   private String vac_edad_mes7 = "0";
/*  17: 24 */   private String vac_edad_mes8 = "0";
/*  18: 25 */   private String vac_edad_mes9 = "0";
/*  19: 26 */   private String vac_edad_mes10 = "0";
/*  20: 27 */   private String vac_edad_mes11 = "0";
/*  21: 28 */   private String vac_edad_mes12 = "0";
/*  22: 29 */   private String vac_edad_mes13 = "0";
/*  23: 30 */   private String vac_edad_mes14 = "0";
/*  24: 31 */   private String vac_edad_mes15 = "0";
/*  25: 32 */   private String vac_edad_mes16 = "0";
/*  26: 33 */   private String vac_edad_mes17 = "0";
/*  27: 34 */   private String vac_edad_mes18 = "0";
/*  28: 35 */   private String vac_edad_mes19 = "0";
/*  29: 36 */   private String vac_edad_mes20 = "0";
/*  30: 37 */   private String vac_edad_mes21 = "0";
/*  31: 38 */   private String vac_edad_mes22 = "0";
/*  32: 39 */   private String vac_edad_mes23 = "0";
/*  33: 40 */   private String vac_edad_mes24 = "0";
/*  34: 41 */   private String vac_edad_anno3 = "0";
/*  35: 42 */   private String vac_edad_anno4 = "0";
/*  36: 43 */   private String vac_edad_anno5 = "0";
/*  37: 44 */   private String vac_edad_anno6 = "0";
/*  38: 45 */   private String vac_edad_anno7 = "0";
/*  39: 46 */   private String vac_edad_anno8 = "0";
/*  40: 47 */   private String vac_edad_anno9 = "0";
/*  41: 48 */   private String vac_edad_anno10 = "0";
/*  42: 49 */   private String vac_edad_anno11 = "0";
/*  43: 50 */   private String vac_edad_anno12 = "0";
/*  44: 51 */   private String vac_edad_anno13 = "0";
/*  45: 52 */   private String vac_edad_anno14 = "0";
/*  46: 53 */   private String vac_edad_anno15 = "0";
/*  47: 54 */   private String vac_edad_anno16 = "0";
/*  48: 55 */   private String vac_edad_anno17 = "0";
/*  49: 56 */   private String vac_edad_anno18 = "0";
/*  50: 57 */   private String vac_edad_anno20 = "0";
/*  51: 58 */   private String vac_edad_anno30 = "0";
/*  52: 59 */   private String vac_edad_anno40 = "0";
/*  53: 60 */   private String vac_edad_anno50 = "0";
/*  54: 61 */   private String vac_edad_anno60 = "0";
/*  55: 62 */   private String vac_edad_anno70 = "0";
/*  56: 63 */   private String vac_edad_anno80 = "0";
/*  57: 64 */   private String vac_edad_anno90 = "0";
/*  58:    */   
/*  59:    */   public String getVac_cod()
/*  60:    */   {
/*  61: 67 */     return this.vac_cod;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public String getVac_des()
/*  65:    */   {
/*  66: 71 */     return this.vac_des;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public String getVac_edad_anno10()
/*  70:    */   {
/*  71: 75 */     return this.vac_edad_anno10;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public String getVac_edad_anno11()
/*  75:    */   {
/*  76: 79 */     return this.vac_edad_anno11;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public String getVac_edad_anno12()
/*  80:    */   {
/*  81: 83 */     return this.vac_edad_anno12;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public String getVac_edad_anno13()
/*  85:    */   {
/*  86: 87 */     return this.vac_edad_anno13;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public String getVac_edad_anno14()
/*  90:    */   {
/*  91: 91 */     return this.vac_edad_anno14;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public String getVac_edad_anno15()
/*  95:    */   {
/*  96: 95 */     return this.vac_edad_anno15;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public String getVac_edad_anno16()
/* 100:    */   {
/* 101: 99 */     return this.vac_edad_anno16;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public String getVac_edad_anno17()
/* 105:    */   {
/* 106:103 */     return this.vac_edad_anno17;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public String getVac_edad_anno18()
/* 110:    */   {
/* 111:107 */     return this.vac_edad_anno18;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public String getVac_edad_anno20()
/* 115:    */   {
/* 116:111 */     return this.vac_edad_anno20;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public String getVac_edad_anno3()
/* 120:    */   {
/* 121:115 */     return this.vac_edad_anno3;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public String getVac_edad_anno30()
/* 125:    */   {
/* 126:119 */     return this.vac_edad_anno30;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public String getVac_edad_anno4()
/* 130:    */   {
/* 131:123 */     return this.vac_edad_anno4;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public String getVac_edad_anno40()
/* 135:    */   {
/* 136:127 */     return this.vac_edad_anno40;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public String getVac_edad_anno5()
/* 140:    */   {
/* 141:131 */     return this.vac_edad_anno5;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public String getVac_edad_anno50()
/* 145:    */   {
/* 146:135 */     return this.vac_edad_anno50;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public String getVac_edad_anno6()
/* 150:    */   {
/* 151:139 */     return this.vac_edad_anno6;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public String getVac_edad_anno60()
/* 155:    */   {
/* 156:143 */     return this.vac_edad_anno60;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public String getVac_edad_anno7()
/* 160:    */   {
/* 161:147 */     return this.vac_edad_anno7;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public String getVac_edad_anno70()
/* 165:    */   {
/* 166:151 */     return this.vac_edad_anno70;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public String getVac_edad_anno8()
/* 170:    */   {
/* 171:155 */     return this.vac_edad_anno8;
/* 172:    */   }
/* 173:    */   
/* 174:    */   public String getVac_edad_anno80()
/* 175:    */   {
/* 176:159 */     return this.vac_edad_anno80;
/* 177:    */   }
/* 178:    */   
/* 179:    */   public String getVac_edad_anno9()
/* 180:    */   {
/* 181:163 */     return this.vac_edad_anno9;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public String getVac_edad_anno90()
/* 185:    */   {
/* 186:167 */     return this.vac_edad_anno90;
/* 187:    */   }
/* 188:    */   
/* 189:    */   public String getVac_edad_mes1()
/* 190:    */   {
/* 191:171 */     return this.vac_edad_mes1;
/* 192:    */   }
/* 193:    */   
/* 194:    */   public String getVac_edad_mes10()
/* 195:    */   {
/* 196:175 */     return this.vac_edad_mes10;
/* 197:    */   }
/* 198:    */   
/* 199:    */   public String getVac_edad_mes11()
/* 200:    */   {
/* 201:179 */     return this.vac_edad_mes11;
/* 202:    */   }
/* 203:    */   
/* 204:    */   public String getVac_edad_mes12()
/* 205:    */   {
/* 206:183 */     return this.vac_edad_mes12;
/* 207:    */   }
/* 208:    */   
/* 209:    */   public String getVac_edad_mes13()
/* 210:    */   {
/* 211:187 */     return this.vac_edad_mes13;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public String getVac_edad_mes14()
/* 215:    */   {
/* 216:191 */     return this.vac_edad_mes14;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public String getVac_edad_mes15()
/* 220:    */   {
/* 221:195 */     return this.vac_edad_mes15;
/* 222:    */   }
/* 223:    */   
/* 224:    */   public String getVac_edad_mes16()
/* 225:    */   {
/* 226:199 */     return this.vac_edad_mes16;
/* 227:    */   }
/* 228:    */   
/* 229:    */   public String getVac_edad_mes17()
/* 230:    */   {
/* 231:203 */     return this.vac_edad_mes17;
/* 232:    */   }
/* 233:    */   
/* 234:    */   public String getVac_edad_mes18()
/* 235:    */   {
/* 236:207 */     return this.vac_edad_mes18;
/* 237:    */   }
/* 238:    */   
/* 239:    */   public String getVac_edad_mes19()
/* 240:    */   {
/* 241:211 */     return this.vac_edad_mes19;
/* 242:    */   }
/* 243:    */   
/* 244:    */   public String getVac_edad_mes2()
/* 245:    */   {
/* 246:215 */     return this.vac_edad_mes2;
/* 247:    */   }
/* 248:    */   
/* 249:    */   public String getVac_edad_mes20()
/* 250:    */   {
/* 251:219 */     return this.vac_edad_mes20;
/* 252:    */   }
/* 253:    */   
/* 254:    */   public String getVac_edad_mes21()
/* 255:    */   {
/* 256:223 */     return this.vac_edad_mes21;
/* 257:    */   }
/* 258:    */   
/* 259:    */   public String getVac_edad_mes22()
/* 260:    */   {
/* 261:227 */     return this.vac_edad_mes22;
/* 262:    */   }
/* 263:    */   
/* 264:    */   public String getVac_edad_mes23()
/* 265:    */   {
/* 266:231 */     return this.vac_edad_mes23;
/* 267:    */   }
/* 268:    */   
/* 269:    */   public String getVac_edad_mes24()
/* 270:    */   {
/* 271:235 */     return this.vac_edad_mes24;
/* 272:    */   }
/* 273:    */   
/* 274:    */   public String getVac_edad_mes3()
/* 275:    */   {
/* 276:239 */     return this.vac_edad_mes3;
/* 277:    */   }
/* 278:    */   
/* 279:    */   public String getVac_edad_mes4()
/* 280:    */   {
/* 281:243 */     return this.vac_edad_mes4;
/* 282:    */   }
/* 283:    */   
/* 284:    */   public String getVac_edad_mes5()
/* 285:    */   {
/* 286:247 */     return this.vac_edad_mes5;
/* 287:    */   }
/* 288:    */   
/* 289:    */   public String getVac_edad_mes6()
/* 290:    */   {
/* 291:251 */     return this.vac_edad_mes6;
/* 292:    */   }
/* 293:    */   
/* 294:    */   public String getVac_edad_mes7()
/* 295:    */   {
/* 296:255 */     return this.vac_edad_mes7;
/* 297:    */   }
/* 298:    */   
/* 299:    */   public String getVac_edad_mes8()
/* 300:    */   {
/* 301:259 */     return this.vac_edad_mes8;
/* 302:    */   }
/* 303:    */   
/* 304:    */   public String getVac_edad_mes9()
/* 305:    */   {
/* 306:263 */     return this.vac_edad_mes9;
/* 307:    */   }
/* 308:    */   
/* 309:    */   public void setVac_cod(String string)
/* 310:    */   {
/* 311:267 */     this.vac_cod = string;
/* 312:    */   }
/* 313:    */   
/* 314:    */   public void setVac_des(String string)
/* 315:    */   {
/* 316:271 */     this.vac_des = string;
/* 317:    */   }
/* 318:    */   
/* 319:    */   public void setVac_edad_anno10(String string)
/* 320:    */   {
/* 321:275 */     this.vac_edad_anno10 = string;
/* 322:    */   }
/* 323:    */   
/* 324:    */   public void setVac_edad_anno11(String string)
/* 325:    */   {
/* 326:279 */     this.vac_edad_anno11 = string;
/* 327:    */   }
/* 328:    */   
/* 329:    */   public void setVac_edad_anno12(String string)
/* 330:    */   {
/* 331:283 */     this.vac_edad_anno12 = string;
/* 332:    */   }
/* 333:    */   
/* 334:    */   public void setVac_edad_anno13(String string)
/* 335:    */   {
/* 336:287 */     this.vac_edad_anno13 = string;
/* 337:    */   }
/* 338:    */   
/* 339:    */   public void setVac_edad_anno14(String string)
/* 340:    */   {
/* 341:291 */     this.vac_edad_anno14 = string;
/* 342:    */   }
/* 343:    */   
/* 344:    */   public void setVac_edad_anno15(String string)
/* 345:    */   {
/* 346:295 */     this.vac_edad_anno15 = string;
/* 347:    */   }
/* 348:    */   
/* 349:    */   public void setVac_edad_anno16(String string)
/* 350:    */   {
/* 351:299 */     this.vac_edad_anno16 = string;
/* 352:    */   }
/* 353:    */   
/* 354:    */   public void setVac_edad_anno17(String string)
/* 355:    */   {
/* 356:303 */     this.vac_edad_anno17 = string;
/* 357:    */   }
/* 358:    */   
/* 359:    */   public void setVac_edad_anno18(String string)
/* 360:    */   {
/* 361:307 */     this.vac_edad_anno18 = string;
/* 362:    */   }
/* 363:    */   
/* 364:    */   public void setVac_edad_anno20(String string)
/* 365:    */   {
/* 366:311 */     this.vac_edad_anno20 = string;
/* 367:    */   }
/* 368:    */   
/* 369:    */   public void setVac_edad_anno3(String string)
/* 370:    */   {
/* 371:315 */     this.vac_edad_anno3 = string;
/* 372:    */   }
/* 373:    */   
/* 374:    */   public void setVac_edad_anno30(String string)
/* 375:    */   {
/* 376:319 */     this.vac_edad_anno30 = string;
/* 377:    */   }
/* 378:    */   
/* 379:    */   public void setVac_edad_anno4(String string)
/* 380:    */   {
/* 381:323 */     this.vac_edad_anno4 = string;
/* 382:    */   }
/* 383:    */   
/* 384:    */   public void setVac_edad_anno40(String string)
/* 385:    */   {
/* 386:327 */     this.vac_edad_anno40 = string;
/* 387:    */   }
/* 388:    */   
/* 389:    */   public void setVac_edad_anno5(String string)
/* 390:    */   {
/* 391:331 */     this.vac_edad_anno5 = string;
/* 392:    */   }
/* 393:    */   
/* 394:    */   public void setVac_edad_anno50(String string)
/* 395:    */   {
/* 396:335 */     this.vac_edad_anno50 = string;
/* 397:    */   }
/* 398:    */   
/* 399:    */   public void setVac_edad_anno6(String string)
/* 400:    */   {
/* 401:339 */     this.vac_edad_anno6 = string;
/* 402:    */   }
/* 403:    */   
/* 404:    */   public void setVac_edad_anno60(String string)
/* 405:    */   {
/* 406:343 */     this.vac_edad_anno60 = string;
/* 407:    */   }
/* 408:    */   
/* 409:    */   public void setVac_edad_anno7(String string)
/* 410:    */   {
/* 411:347 */     this.vac_edad_anno7 = string;
/* 412:    */   }
/* 413:    */   
/* 414:    */   public void setVac_edad_anno70(String string)
/* 415:    */   {
/* 416:351 */     this.vac_edad_anno70 = string;
/* 417:    */   }
/* 418:    */   
/* 419:    */   public void setVac_edad_anno8(String string)
/* 420:    */   {
/* 421:355 */     this.vac_edad_anno8 = string;
/* 422:    */   }
/* 423:    */   
/* 424:    */   public void setVac_edad_anno80(String string)
/* 425:    */   {
/* 426:359 */     this.vac_edad_anno80 = string;
/* 427:    */   }
/* 428:    */   
/* 429:    */   public void setVac_edad_anno9(String string)
/* 430:    */   {
/* 431:363 */     this.vac_edad_anno9 = string;
/* 432:    */   }
/* 433:    */   
/* 434:    */   public void setVac_edad_anno90(String string)
/* 435:    */   {
/* 436:367 */     this.vac_edad_anno90 = string;
/* 437:    */   }
/* 438:    */   
/* 439:    */   public void setVac_edad_mes1(String string)
/* 440:    */   {
/* 441:371 */     this.vac_edad_mes1 = string;
/* 442:    */   }
/* 443:    */   
/* 444:    */   public void setVac_edad_mes10(String string)
/* 445:    */   {
/* 446:375 */     this.vac_edad_mes10 = string;
/* 447:    */   }
/* 448:    */   
/* 449:    */   public void setVac_edad_mes11(String string)
/* 450:    */   {
/* 451:379 */     this.vac_edad_mes11 = string;
/* 452:    */   }
/* 453:    */   
/* 454:    */   public void setVac_edad_mes12(String string)
/* 455:    */   {
/* 456:383 */     this.vac_edad_mes12 = string;
/* 457:    */   }
/* 458:    */   
/* 459:    */   public void setVac_edad_mes13(String string)
/* 460:    */   {
/* 461:387 */     this.vac_edad_mes13 = string;
/* 462:    */   }
/* 463:    */   
/* 464:    */   public void setVac_edad_mes14(String string)
/* 465:    */   {
/* 466:391 */     this.vac_edad_mes14 = string;
/* 467:    */   }
/* 468:    */   
/* 469:    */   public void setVac_edad_mes15(String string)
/* 470:    */   {
/* 471:395 */     this.vac_edad_mes15 = string;
/* 472:    */   }
/* 473:    */   
/* 474:    */   public void setVac_edad_mes16(String string)
/* 475:    */   {
/* 476:399 */     this.vac_edad_mes16 = string;
/* 477:    */   }
/* 478:    */   
/* 479:    */   public void setVac_edad_mes17(String string)
/* 480:    */   {
/* 481:403 */     this.vac_edad_mes17 = string;
/* 482:    */   }
/* 483:    */   
/* 484:    */   public void setVac_edad_mes18(String string)
/* 485:    */   {
/* 486:407 */     this.vac_edad_mes18 = string;
/* 487:    */   }
/* 488:    */   
/* 489:    */   public void setVac_edad_mes19(String string)
/* 490:    */   {
/* 491:411 */     this.vac_edad_mes19 = string;
/* 492:    */   }
/* 493:    */   
/* 494:    */   public void setVac_edad_mes2(String string)
/* 495:    */   {
/* 496:415 */     this.vac_edad_mes2 = string;
/* 497:    */   }
/* 498:    */   
/* 499:    */   public void setVac_edad_mes20(String string)
/* 500:    */   {
/* 501:419 */     this.vac_edad_mes20 = string;
/* 502:    */   }
/* 503:    */   
/* 504:    */   public void setVac_edad_mes21(String string)
/* 505:    */   {
/* 506:423 */     this.vac_edad_mes21 = string;
/* 507:    */   }
/* 508:    */   
/* 509:    */   public void setVac_edad_mes22(String string)
/* 510:    */   {
/* 511:427 */     this.vac_edad_mes22 = string;
/* 512:    */   }
/* 513:    */   
/* 514:    */   public void setVac_edad_mes23(String string)
/* 515:    */   {
/* 516:431 */     this.vac_edad_mes23 = string;
/* 517:    */   }
/* 518:    */   
/* 519:    */   public void setVac_edad_mes24(String string)
/* 520:    */   {
/* 521:435 */     this.vac_edad_mes24 = string;
/* 522:    */   }
/* 523:    */   
/* 524:    */   public void setVac_edad_mes3(String string)
/* 525:    */   {
/* 526:439 */     this.vac_edad_mes3 = string;
/* 527:    */   }
/* 528:    */   
/* 529:    */   public void setVac_edad_mes4(String string)
/* 530:    */   {
/* 531:443 */     this.vac_edad_mes4 = string;
/* 532:    */   }
/* 533:    */   
/* 534:    */   public void setVac_edad_mes5(String string)
/* 535:    */   {
/* 536:447 */     this.vac_edad_mes5 = string;
/* 537:    */   }
/* 538:    */   
/* 539:    */   public void setVac_edad_mes6(String string)
/* 540:    */   {
/* 541:451 */     this.vac_edad_mes6 = string;
/* 542:    */   }
/* 543:    */   
/* 544:    */   public void setVac_edad_mes7(String string)
/* 545:    */   {
/* 546:455 */     this.vac_edad_mes7 = string;
/* 547:    */   }
/* 548:    */   
/* 549:    */   public void setVac_edad_mes8(String string)
/* 550:    */   {
/* 551:459 */     this.vac_edad_mes8 = string;
/* 552:    */   }
/* 553:    */   
/* 554:    */   public void setVac_edad_mes9(String string)
/* 555:    */   {
/* 556:463 */     this.vac_edad_mes9 = string;
/* 557:    */   }
/* 558:    */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.parametros.controller.VacunasForm
 * JD-Core Version:    0.7.0.1
 */