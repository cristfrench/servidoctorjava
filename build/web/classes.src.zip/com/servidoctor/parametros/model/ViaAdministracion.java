/*  1:   */ package com.servidoctor.parametros.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class ViaAdministracion
/*  6:   */ {
/*  7:   */   private BigDecimal vadm_cod;
/*  8:   */   private String vadm_des;
/*  9:   */   
/* 10:   */   public BigDecimal getVadm_cod()
/* 11:   */   {
/* 12:18 */     return this.vadm_cod;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public String getVadm_des()
/* 16:   */   {
/* 17:22 */     return this.vadm_des;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setVadm_cod(BigDecimal decimal)
/* 21:   */   {
/* 22:26 */     this.vadm_cod = decimal;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setVadm_des(String string)
/* 26:   */   {
/* 27:30 */     this.vadm_des = string;
/* 28:   */   }
/* 29:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.parametros.model.ViaAdministracion
 * JD-Core Version:    0.7.0.1
 */