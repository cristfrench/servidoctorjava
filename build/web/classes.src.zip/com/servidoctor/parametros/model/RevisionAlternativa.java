/*  1:   */ package com.servidoctor.parametros.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class RevisionAlternativa
/*  6:   */ {
/*  7:   */   private BigDecimal ralt_cod;
/*  8:   */   private String ralt_des;
/*  9:   */   
/* 10:   */   public BigDecimal getRalt_cod()
/* 11:   */   {
/* 12:17 */     return this.ralt_cod;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public String getRalt_des()
/* 16:   */   {
/* 17:21 */     return this.ralt_des;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setRalt_cod(BigDecimal decimal)
/* 21:   */   {
/* 22:25 */     this.ralt_cod = decimal;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setRalt_des(String string)
/* 26:   */   {
/* 27:29 */     this.ralt_des = string;
/* 28:   */   }
/* 29:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.parametros.model.RevisionAlternativa
 * JD-Core Version:    0.7.0.1
 */