/*  1:   */ package com.servidoctor.parametros.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class Sistemas
/*  6:   */ {
/*  7:   */   private BigDecimal sis_cod;
/*  8:   */   private String sis_desc;
/*  9:   */   
/* 10:   */   public BigDecimal getSis_cod()
/* 11:   */   {
/* 12:15 */     return this.sis_cod;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public String getSis_desc()
/* 16:   */   {
/* 17:19 */     return this.sis_desc;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setSis_cod(BigDecimal decimal)
/* 21:   */   {
/* 22:23 */     this.sis_cod = decimal;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setSis_desc(String string)
/* 26:   */   {
/* 27:27 */     this.sis_desc = string;
/* 28:   */   }
/* 29:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.parametros.model.Sistemas
 * JD-Core Version:    0.7.0.1
 */