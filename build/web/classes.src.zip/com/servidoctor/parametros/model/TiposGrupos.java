/*  1:   */ package com.servidoctor.parametros.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class TiposGrupos
/*  6:   */ {
/*  7:   */   private BigDecimal tipg_cod;
/*  8:   */   private String tipg_des;
/*  9:   */   
/* 10:   */   public BigDecimal getTipg_cod()
/* 11:   */   {
/* 12:18 */     return this.tipg_cod;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public String getTipg_des()
/* 16:   */   {
/* 17:22 */     return this.tipg_des;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setTipg_cod(BigDecimal decimal)
/* 21:   */   {
/* 22:26 */     this.tipg_cod = decimal;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setTipg_des(String string)
/* 26:   */   {
/* 27:30 */     this.tipg_des = string;
/* 28:   */   }
/* 29:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.parametros.model.TiposGrupos
 * JD-Core Version:    0.7.0.1
 */