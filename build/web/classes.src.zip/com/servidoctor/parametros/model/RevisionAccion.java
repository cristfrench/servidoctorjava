/*  1:   */ package com.servidoctor.parametros.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class RevisionAccion
/*  6:   */ {
/*  7:   */   BigDecimal racc_cod;
/*  8:   */   String racc_des;
/*  9:   */   
/* 10:   */   public BigDecimal getRacc_cod()
/* 11:   */   {
/* 12:25 */     return this.racc_cod;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public String getRacc_des()
/* 16:   */   {
/* 17:32 */     return this.racc_des;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setRacc_cod(BigDecimal decimal)
/* 21:   */   {
/* 22:39 */     this.racc_cod = decimal;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setRacc_des(String string)
/* 26:   */   {
/* 27:46 */     this.racc_des = string;
/* 28:   */   }
/* 29:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.parametros.model.RevisionAccion
 * JD-Core Version:    0.7.0.1
 */