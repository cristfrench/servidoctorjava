/*  1:   */ package com.servidoctor.parametros.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class GinecologiaOperaciones
/*  6:   */ {
/*  7:   */   private BigDecimal gope_cod;
/*  8:   */   private String gope_des;
/*  9:   */   
/* 10:   */   public BigDecimal getGope_cod()
/* 11:   */   {
/* 12:19 */     return this.gope_cod;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public String getGope_des()
/* 16:   */   {
/* 17:23 */     return this.gope_des;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setGope_cod(BigDecimal decimal)
/* 21:   */   {
/* 22:27 */     this.gope_cod = decimal;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setGope_des(String string)
/* 26:   */   {
/* 27:31 */     this.gope_des = string;
/* 28:   */   }
/* 29:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.parametros.model.GinecologiaOperaciones
 * JD-Core Version:    0.7.0.1
 */