/*  1:   */ package com.servidoctor.parametros.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class Escolaridad
/*  6:   */ {
/*  7:   */   BigDecimal esco_cod;
/*  8:   */   String esco_des;
/*  9:   */   
/* 10:   */   public BigDecimal getEsco_cod()
/* 11:   */   {
/* 12:28 */     return this.esco_cod;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public String getEsco_des()
/* 16:   */   {
/* 17:35 */     return this.esco_des;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setEsco_cod(BigDecimal decimal)
/* 21:   */   {
/* 22:42 */     this.esco_cod = decimal;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setEsco_des(String string)
/* 26:   */   {
/* 27:49 */     this.esco_des = string;
/* 28:   */   }
/* 29:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.parametros.model.Escolaridad
 * JD-Core Version:    0.7.0.1
 */