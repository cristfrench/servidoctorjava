/*  1:   */ package com.servidoctor.parametros.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class Forma
/*  6:   */ {
/*  7:   */   private BigDecimal form_cod;
/*  8:   */   private String form_des;
/*  9:   */   
/* 10:   */   public BigDecimal getForm_cod()
/* 11:   */   {
/* 12:18 */     return this.form_cod;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public String getForm_des()
/* 16:   */   {
/* 17:22 */     return this.form_des;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setForm_cod(BigDecimal decimal)
/* 21:   */   {
/* 22:26 */     this.form_cod = decimal;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setForm_des(String string)
/* 26:   */   {
/* 27:30 */     this.form_des = string;
/* 28:   */   }
/* 29:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.parametros.model.Forma
 * JD-Core Version:    0.7.0.1
 */