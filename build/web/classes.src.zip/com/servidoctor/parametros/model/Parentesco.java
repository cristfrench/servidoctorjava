/*  1:   */ package com.servidoctor.parametros.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class Parentesco
/*  6:   */ {
/*  7:   */   private BigDecimal rfam_cod;
/*  8:   */   private String rfam_des;
/*  9:   */   
/* 10:   */   public BigDecimal getRfam_cod()
/* 11:   */   {
/* 12:17 */     return this.rfam_cod;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public String getRfam_des()
/* 16:   */   {
/* 17:21 */     return this.rfam_des;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setRfam_cod(BigDecimal decimal)
/* 21:   */   {
/* 22:25 */     this.rfam_cod = decimal;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setRfam_des(String string)
/* 26:   */   {
/* 27:29 */     this.rfam_des = string;
/* 28:   */   }
/* 29:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.parametros.model.Parentesco
 * JD-Core Version:    0.7.0.1
 */