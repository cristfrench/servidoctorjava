/*   1:    */ package com.servidoctor.parametros.model;
/*   2:    */ 
/*   3:    */ import java.math.BigDecimal;
/*   4:    */ 
/*   5:    */ public class Vacunas
/*   6:    */ {
/*   7:    */   private BigDecimal vac_cod;
/*   8:    */   private String vac_des;
/*   9:    */   private BigDecimal vac_edad_mes1;
/*  10:    */   private BigDecimal vac_edad_mes2;
/*  11:    */   private BigDecimal vac_edad_mes3;
/*  12:    */   private BigDecimal vac_edad_mes4;
/*  13:    */   private BigDecimal vac_edad_mes5;
/*  14:    */   private BigDecimal vac_edad_mes6;
/*  15:    */   private BigDecimal vac_edad_mes7;
/*  16:    */   private BigDecimal vac_edad_mes8;
/*  17:    */   private BigDecimal vac_edad_mes9;
/*  18:    */   private BigDecimal vac_edad_mes10;
/*  19:    */   private BigDecimal vac_edad_mes11;
/*  20:    */   private BigDecimal vac_edad_mes12;
/*  21:    */   private BigDecimal vac_edad_mes13;
/*  22:    */   private BigDecimal vac_edad_mes14;
/*  23:    */   private BigDecimal vac_edad_mes15;
/*  24:    */   private BigDecimal vac_edad_mes16;
/*  25:    */   private BigDecimal vac_edad_mes17;
/*  26:    */   private BigDecimal vac_edad_mes18;
/*  27:    */   private BigDecimal vac_edad_mes19;
/*  28:    */   private BigDecimal vac_edad_mes20;
/*  29:    */   private BigDecimal vac_edad_mes21;
/*  30:    */   private BigDecimal vac_edad_mes22;
/*  31:    */   private BigDecimal vac_edad_mes23;
/*  32:    */   private BigDecimal vac_edad_mes24;
/*  33:    */   private BigDecimal vac_edad_anno3;
/*  34:    */   private BigDecimal vac_edad_anno4;
/*  35:    */   private BigDecimal vac_edad_anno5;
/*  36:    */   private BigDecimal vac_edad_anno6;
/*  37:    */   private BigDecimal vac_edad_anno7;
/*  38:    */   private BigDecimal vac_edad_anno8;
/*  39:    */   private BigDecimal vac_edad_anno9;
/*  40:    */   private BigDecimal vac_edad_anno10;
/*  41:    */   private BigDecimal vac_edad_anno11;
/*  42:    */   private BigDecimal vac_edad_anno12;
/*  43:    */   private BigDecimal vac_edad_anno13;
/*  44:    */   private BigDecimal vac_edad_anno14;
/*  45:    */   private BigDecimal vac_edad_anno15;
/*  46:    */   private BigDecimal vac_edad_anno16;
/*  47:    */   private BigDecimal vac_edad_anno17;
/*  48:    */   private BigDecimal vac_edad_anno18;
/*  49:    */   private BigDecimal vac_edad_anno19;
/*  50:    */   private BigDecimal vac_edad_anno20;
/*  51:    */   private BigDecimal vac_edad_anno30;
/*  52:    */   private BigDecimal vac_edad_anno40;
/*  53:    */   private BigDecimal vac_edad_anno50;
/*  54:    */   private BigDecimal vac_edad_anno60;
/*  55:    */   private BigDecimal vac_edad_anno70;
/*  56:    */   private BigDecimal vac_edad_anno80;
/*  57:    */   private BigDecimal vac_edad_anno90;
/*  58:    */   
/*  59:    */   public BigDecimal getVac_cod()
/*  60:    */   {
/*  61: 68 */     return this.vac_cod;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public String getVac_des()
/*  65:    */   {
/*  66: 72 */     return this.vac_des;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public BigDecimal getVac_edad_anno10()
/*  70:    */   {
/*  71: 76 */     return this.vac_edad_anno10;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public BigDecimal getVac_edad_anno11()
/*  75:    */   {
/*  76: 80 */     return this.vac_edad_anno11;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public BigDecimal getVac_edad_anno12()
/*  80:    */   {
/*  81: 84 */     return this.vac_edad_anno12;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public BigDecimal getVac_edad_anno13()
/*  85:    */   {
/*  86: 88 */     return this.vac_edad_anno13;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public BigDecimal getVac_edad_anno14()
/*  90:    */   {
/*  91: 92 */     return this.vac_edad_anno14;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public BigDecimal getVac_edad_anno15()
/*  95:    */   {
/*  96: 96 */     return this.vac_edad_anno15;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public BigDecimal getVac_edad_anno16()
/* 100:    */   {
/* 101:100 */     return this.vac_edad_anno16;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public BigDecimal getVac_edad_anno17()
/* 105:    */   {
/* 106:104 */     return this.vac_edad_anno17;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public BigDecimal getVac_edad_anno18()
/* 110:    */   {
/* 111:108 */     return this.vac_edad_anno18;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public BigDecimal getVac_edad_anno20()
/* 115:    */   {
/* 116:112 */     return this.vac_edad_anno20;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public BigDecimal getVac_edad_anno3()
/* 120:    */   {
/* 121:116 */     return this.vac_edad_anno3;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public BigDecimal getVac_edad_anno30()
/* 125:    */   {
/* 126:120 */     return this.vac_edad_anno30;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public BigDecimal getVac_edad_anno4()
/* 130:    */   {
/* 131:124 */     return this.vac_edad_anno4;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public BigDecimal getVac_edad_anno40()
/* 135:    */   {
/* 136:128 */     return this.vac_edad_anno40;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public BigDecimal getVac_edad_anno5()
/* 140:    */   {
/* 141:132 */     return this.vac_edad_anno5;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public BigDecimal getVac_edad_anno50()
/* 145:    */   {
/* 146:136 */     return this.vac_edad_anno50;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public BigDecimal getVac_edad_anno6()
/* 150:    */   {
/* 151:140 */     return this.vac_edad_anno6;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public BigDecimal getVac_edad_anno60()
/* 155:    */   {
/* 156:144 */     return this.vac_edad_anno60;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public BigDecimal getVac_edad_anno7()
/* 160:    */   {
/* 161:148 */     return this.vac_edad_anno7;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public BigDecimal getVac_edad_anno70()
/* 165:    */   {
/* 166:152 */     return this.vac_edad_anno70;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public BigDecimal getVac_edad_anno8()
/* 170:    */   {
/* 171:156 */     return this.vac_edad_anno8;
/* 172:    */   }
/* 173:    */   
/* 174:    */   public BigDecimal getVac_edad_anno80()
/* 175:    */   {
/* 176:160 */     return this.vac_edad_anno80;
/* 177:    */   }
/* 178:    */   
/* 179:    */   public BigDecimal getVac_edad_anno9()
/* 180:    */   {
/* 181:164 */     return this.vac_edad_anno9;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public BigDecimal getVac_edad_anno90()
/* 185:    */   {
/* 186:168 */     return this.vac_edad_anno90;
/* 187:    */   }
/* 188:    */   
/* 189:    */   public BigDecimal getVac_edad_mes1()
/* 190:    */   {
/* 191:172 */     return this.vac_edad_mes1;
/* 192:    */   }
/* 193:    */   
/* 194:    */   public BigDecimal getVac_edad_mes10()
/* 195:    */   {
/* 196:176 */     return this.vac_edad_mes10;
/* 197:    */   }
/* 198:    */   
/* 199:    */   public BigDecimal getVac_edad_mes11()
/* 200:    */   {
/* 201:180 */     return this.vac_edad_mes11;
/* 202:    */   }
/* 203:    */   
/* 204:    */   public BigDecimal getVac_edad_mes12()
/* 205:    */   {
/* 206:184 */     return this.vac_edad_mes12;
/* 207:    */   }
/* 208:    */   
/* 209:    */   public BigDecimal getVac_edad_mes13()
/* 210:    */   {
/* 211:188 */     return this.vac_edad_mes13;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public BigDecimal getVac_edad_mes14()
/* 215:    */   {
/* 216:192 */     return this.vac_edad_mes14;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public BigDecimal getVac_edad_mes15()
/* 220:    */   {
/* 221:196 */     return this.vac_edad_mes15;
/* 222:    */   }
/* 223:    */   
/* 224:    */   public BigDecimal getVac_edad_mes16()
/* 225:    */   {
/* 226:200 */     return this.vac_edad_mes16;
/* 227:    */   }
/* 228:    */   
/* 229:    */   public BigDecimal getVac_edad_mes17()
/* 230:    */   {
/* 231:204 */     return this.vac_edad_mes17;
/* 232:    */   }
/* 233:    */   
/* 234:    */   public BigDecimal getVac_edad_mes18()
/* 235:    */   {
/* 236:208 */     return this.vac_edad_mes18;
/* 237:    */   }
/* 238:    */   
/* 239:    */   public BigDecimal getVac_edad_mes19()
/* 240:    */   {
/* 241:212 */     return this.vac_edad_mes19;
/* 242:    */   }
/* 243:    */   
/* 244:    */   public BigDecimal getVac_edad_mes2()
/* 245:    */   {
/* 246:216 */     return this.vac_edad_mes2;
/* 247:    */   }
/* 248:    */   
/* 249:    */   public BigDecimal getVac_edad_mes20()
/* 250:    */   {
/* 251:220 */     return this.vac_edad_mes20;
/* 252:    */   }
/* 253:    */   
/* 254:    */   public BigDecimal getVac_edad_mes21()
/* 255:    */   {
/* 256:224 */     return this.vac_edad_mes21;
/* 257:    */   }
/* 258:    */   
/* 259:    */   public BigDecimal getVac_edad_mes22()
/* 260:    */   {
/* 261:228 */     return this.vac_edad_mes22;
/* 262:    */   }
/* 263:    */   
/* 264:    */   public BigDecimal getVac_edad_mes23()
/* 265:    */   {
/* 266:232 */     return this.vac_edad_mes23;
/* 267:    */   }
/* 268:    */   
/* 269:    */   public BigDecimal getVac_edad_mes24()
/* 270:    */   {
/* 271:236 */     return this.vac_edad_mes24;
/* 272:    */   }
/* 273:    */   
/* 274:    */   public BigDecimal getVac_edad_mes3()
/* 275:    */   {
/* 276:240 */     return this.vac_edad_mes3;
/* 277:    */   }
/* 278:    */   
/* 279:    */   public BigDecimal getVac_edad_mes4()
/* 280:    */   {
/* 281:244 */     return this.vac_edad_mes4;
/* 282:    */   }
/* 283:    */   
/* 284:    */   public BigDecimal getVac_edad_mes5()
/* 285:    */   {
/* 286:248 */     return this.vac_edad_mes5;
/* 287:    */   }
/* 288:    */   
/* 289:    */   public BigDecimal getVac_edad_mes6()
/* 290:    */   {
/* 291:252 */     return this.vac_edad_mes6;
/* 292:    */   }
/* 293:    */   
/* 294:    */   public BigDecimal getVac_edad_mes7()
/* 295:    */   {
/* 296:256 */     return this.vac_edad_mes7;
/* 297:    */   }
/* 298:    */   
/* 299:    */   public BigDecimal getVac_edad_mes8()
/* 300:    */   {
/* 301:260 */     return this.vac_edad_mes8;
/* 302:    */   }
/* 303:    */   
/* 304:    */   public BigDecimal getVac_edad_mes9()
/* 305:    */   {
/* 306:264 */     return this.vac_edad_mes9;
/* 307:    */   }
/* 308:    */   
/* 309:    */   public void setVac_cod(BigDecimal decimal)
/* 310:    */   {
/* 311:268 */     this.vac_cod = decimal;
/* 312:    */   }
/* 313:    */   
/* 314:    */   public void setVac_des(String string)
/* 315:    */   {
/* 316:272 */     this.vac_des = string;
/* 317:    */   }
/* 318:    */   
/* 319:    */   public void setVac_edad_anno10(BigDecimal decimal)
/* 320:    */   {
/* 321:276 */     this.vac_edad_anno10 = decimal;
/* 322:    */   }
/* 323:    */   
/* 324:    */   public void setVac_edad_anno11(BigDecimal decimal)
/* 325:    */   {
/* 326:280 */     this.vac_edad_anno11 = decimal;
/* 327:    */   }
/* 328:    */   
/* 329:    */   public void setVac_edad_anno12(BigDecimal decimal)
/* 330:    */   {
/* 331:284 */     this.vac_edad_anno12 = decimal;
/* 332:    */   }
/* 333:    */   
/* 334:    */   public void setVac_edad_anno13(BigDecimal decimal)
/* 335:    */   {
/* 336:288 */     this.vac_edad_anno13 = decimal;
/* 337:    */   }
/* 338:    */   
/* 339:    */   public void setVac_edad_anno14(BigDecimal decimal)
/* 340:    */   {
/* 341:292 */     this.vac_edad_anno14 = decimal;
/* 342:    */   }
/* 343:    */   
/* 344:    */   public void setVac_edad_anno15(BigDecimal decimal)
/* 345:    */   {
/* 346:296 */     this.vac_edad_anno15 = decimal;
/* 347:    */   }
/* 348:    */   
/* 349:    */   public void setVac_edad_anno16(BigDecimal decimal)
/* 350:    */   {
/* 351:300 */     this.vac_edad_anno16 = decimal;
/* 352:    */   }
/* 353:    */   
/* 354:    */   public void setVac_edad_anno17(BigDecimal decimal)
/* 355:    */   {
/* 356:304 */     this.vac_edad_anno17 = decimal;
/* 357:    */   }
/* 358:    */   
/* 359:    */   public void setVac_edad_anno18(BigDecimal decimal)
/* 360:    */   {
/* 361:308 */     this.vac_edad_anno18 = decimal;
/* 362:    */   }
/* 363:    */   
/* 364:    */   public void setVac_edad_anno20(BigDecimal decimal)
/* 365:    */   {
/* 366:312 */     this.vac_edad_anno20 = decimal;
/* 367:    */   }
/* 368:    */   
/* 369:    */   public void setVac_edad_anno3(BigDecimal decimal)
/* 370:    */   {
/* 371:316 */     this.vac_edad_anno3 = decimal;
/* 372:    */   }
/* 373:    */   
/* 374:    */   public void setVac_edad_anno30(BigDecimal decimal)
/* 375:    */   {
/* 376:320 */     this.vac_edad_anno30 = decimal;
/* 377:    */   }
/* 378:    */   
/* 379:    */   public void setVac_edad_anno4(BigDecimal decimal)
/* 380:    */   {
/* 381:324 */     this.vac_edad_anno4 = decimal;
/* 382:    */   }
/* 383:    */   
/* 384:    */   public void setVac_edad_anno40(BigDecimal decimal)
/* 385:    */   {
/* 386:328 */     this.vac_edad_anno40 = decimal;
/* 387:    */   }
/* 388:    */   
/* 389:    */   public void setVac_edad_anno5(BigDecimal decimal)
/* 390:    */   {
/* 391:332 */     this.vac_edad_anno5 = decimal;
/* 392:    */   }
/* 393:    */   
/* 394:    */   public void setVac_edad_anno50(BigDecimal decimal)
/* 395:    */   {
/* 396:336 */     this.vac_edad_anno50 = decimal;
/* 397:    */   }
/* 398:    */   
/* 399:    */   public void setVac_edad_anno6(BigDecimal decimal)
/* 400:    */   {
/* 401:340 */     this.vac_edad_anno6 = decimal;
/* 402:    */   }
/* 403:    */   
/* 404:    */   public void setVac_edad_anno60(BigDecimal decimal)
/* 405:    */   {
/* 406:344 */     this.vac_edad_anno60 = decimal;
/* 407:    */   }
/* 408:    */   
/* 409:    */   public void setVac_edad_anno7(BigDecimal decimal)
/* 410:    */   {
/* 411:348 */     this.vac_edad_anno7 = decimal;
/* 412:    */   }
/* 413:    */   
/* 414:    */   public void setVac_edad_anno70(BigDecimal decimal)
/* 415:    */   {
/* 416:352 */     this.vac_edad_anno70 = decimal;
/* 417:    */   }
/* 418:    */   
/* 419:    */   public void setVac_edad_anno8(BigDecimal decimal)
/* 420:    */   {
/* 421:356 */     this.vac_edad_anno8 = decimal;
/* 422:    */   }
/* 423:    */   
/* 424:    */   public void setVac_edad_anno80(BigDecimal decimal)
/* 425:    */   {
/* 426:360 */     this.vac_edad_anno80 = decimal;
/* 427:    */   }
/* 428:    */   
/* 429:    */   public void setVac_edad_anno9(BigDecimal decimal)
/* 430:    */   {
/* 431:364 */     this.vac_edad_anno9 = decimal;
/* 432:    */   }
/* 433:    */   
/* 434:    */   public void setVac_edad_anno90(BigDecimal decimal)
/* 435:    */   {
/* 436:368 */     this.vac_edad_anno90 = decimal;
/* 437:    */   }
/* 438:    */   
/* 439:    */   public void setVac_edad_mes1(BigDecimal decimal)
/* 440:    */   {
/* 441:372 */     this.vac_edad_mes1 = decimal;
/* 442:    */   }
/* 443:    */   
/* 444:    */   public void setVac_edad_mes10(BigDecimal decimal)
/* 445:    */   {
/* 446:376 */     this.vac_edad_mes10 = decimal;
/* 447:    */   }
/* 448:    */   
/* 449:    */   public void setVac_edad_mes11(BigDecimal decimal)
/* 450:    */   {
/* 451:380 */     this.vac_edad_mes11 = decimal;
/* 452:    */   }
/* 453:    */   
/* 454:    */   public void setVac_edad_mes12(BigDecimal decimal)
/* 455:    */   {
/* 456:384 */     this.vac_edad_mes12 = decimal;
/* 457:    */   }
/* 458:    */   
/* 459:    */   public void setVac_edad_mes13(BigDecimal decimal)
/* 460:    */   {
/* 461:388 */     this.vac_edad_mes13 = decimal;
/* 462:    */   }
/* 463:    */   
/* 464:    */   public void setVac_edad_mes14(BigDecimal decimal)
/* 465:    */   {
/* 466:392 */     this.vac_edad_mes14 = decimal;
/* 467:    */   }
/* 468:    */   
/* 469:    */   public void setVac_edad_mes15(BigDecimal decimal)
/* 470:    */   {
/* 471:396 */     this.vac_edad_mes15 = decimal;
/* 472:    */   }
/* 473:    */   
/* 474:    */   public void setVac_edad_mes16(BigDecimal decimal)
/* 475:    */   {
/* 476:400 */     this.vac_edad_mes16 = decimal;
/* 477:    */   }
/* 478:    */   
/* 479:    */   public void setVac_edad_mes17(BigDecimal decimal)
/* 480:    */   {
/* 481:404 */     this.vac_edad_mes17 = decimal;
/* 482:    */   }
/* 483:    */   
/* 484:    */   public void setVac_edad_mes18(BigDecimal decimal)
/* 485:    */   {
/* 486:408 */     this.vac_edad_mes18 = decimal;
/* 487:    */   }
/* 488:    */   
/* 489:    */   public void setVac_edad_mes19(BigDecimal decimal)
/* 490:    */   {
/* 491:412 */     this.vac_edad_mes19 = decimal;
/* 492:    */   }
/* 493:    */   
/* 494:    */   public void setVac_edad_mes2(BigDecimal decimal)
/* 495:    */   {
/* 496:416 */     this.vac_edad_mes2 = decimal;
/* 497:    */   }
/* 498:    */   
/* 499:    */   public void setVac_edad_mes20(BigDecimal decimal)
/* 500:    */   {
/* 501:420 */     this.vac_edad_mes20 = decimal;
/* 502:    */   }
/* 503:    */   
/* 504:    */   public void setVac_edad_mes21(BigDecimal decimal)
/* 505:    */   {
/* 506:424 */     this.vac_edad_mes21 = decimal;
/* 507:    */   }
/* 508:    */   
/* 509:    */   public void setVac_edad_mes22(BigDecimal decimal)
/* 510:    */   {
/* 511:428 */     this.vac_edad_mes22 = decimal;
/* 512:    */   }
/* 513:    */   
/* 514:    */   public void setVac_edad_mes23(BigDecimal decimal)
/* 515:    */   {
/* 516:432 */     this.vac_edad_mes23 = decimal;
/* 517:    */   }
/* 518:    */   
/* 519:    */   public void setVac_edad_mes24(BigDecimal decimal)
/* 520:    */   {
/* 521:436 */     this.vac_edad_mes24 = decimal;
/* 522:    */   }
/* 523:    */   
/* 524:    */   public void setVac_edad_mes3(BigDecimal decimal)
/* 525:    */   {
/* 526:440 */     this.vac_edad_mes3 = decimal;
/* 527:    */   }
/* 528:    */   
/* 529:    */   public void setVac_edad_mes4(BigDecimal decimal)
/* 530:    */   {
/* 531:444 */     this.vac_edad_mes4 = decimal;
/* 532:    */   }
/* 533:    */   
/* 534:    */   public void setVac_edad_mes5(BigDecimal decimal)
/* 535:    */   {
/* 536:448 */     this.vac_edad_mes5 = decimal;
/* 537:    */   }
/* 538:    */   
/* 539:    */   public void setVac_edad_mes6(BigDecimal decimal)
/* 540:    */   {
/* 541:452 */     this.vac_edad_mes6 = decimal;
/* 542:    */   }
/* 543:    */   
/* 544:    */   public void setVac_edad_mes7(BigDecimal decimal)
/* 545:    */   {
/* 546:456 */     this.vac_edad_mes7 = decimal;
/* 547:    */   }
/* 548:    */   
/* 549:    */   public void setVac_edad_mes8(BigDecimal decimal)
/* 550:    */   {
/* 551:460 */     this.vac_edad_mes8 = decimal;
/* 552:    */   }
/* 553:    */   
/* 554:    */   public void setVac_edad_mes9(BigDecimal decimal)
/* 555:    */   {
/* 556:464 */     this.vac_edad_mes9 = decimal;
/* 557:    */   }
/* 558:    */   
/* 559:    */   public BigDecimal getVac_edad_anno19()
/* 560:    */   {
/* 561:470 */     return this.vac_edad_anno19;
/* 562:    */   }
/* 563:    */   
/* 564:    */   public void setVac_edad_anno19(BigDecimal vac_edad_anno19)
/* 565:    */   {
/* 566:474 */     this.vac_edad_anno19 = vac_edad_anno19;
/* 567:    */   }
/* 568:    */   
/* 569:    */   public boolean equals(Object object)
/* 570:    */   {
/* 571:478 */     boolean resultado = false;
/* 572:479 */     if (object == this)
/* 573:    */     {
/* 574:480 */       resultado = true;
/* 575:    */     }
/* 576:481 */     else if ((object instanceof Vacunas))
/* 577:    */     {
/* 578:482 */       Vacunas vacunas = (Vacunas)object;
/* 579:483 */       if (this.vac_cod.equals(vacunas.vac_cod)) {
/* 580:484 */         resultado = true;
/* 581:    */       }
/* 582:    */     }
/* 583:487 */     return resultado;
/* 584:    */   }
/* 585:    */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.parametros.model.Vacunas
 * JD-Core Version:    0.7.0.1
 */