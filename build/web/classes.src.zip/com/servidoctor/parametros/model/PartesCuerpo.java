/*  1:   */ package com.servidoctor.parametros.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class PartesCuerpo
/*  6:   */ {
/*  7:   */   private BigDecimal pcue_cod;
/*  8:   */   private String pcue_des;
/*  9:   */   
/* 10:   */   public BigDecimal getPcue_cod()
/* 11:   */   {
/* 12:18 */     return this.pcue_cod;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public String getPcue_des()
/* 16:   */   {
/* 17:22 */     return this.pcue_des;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setPcue_cod(BigDecimal decimal)
/* 21:   */   {
/* 22:26 */     this.pcue_cod = decimal;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setPcue_des(String string)
/* 26:   */   {
/* 27:30 */     this.pcue_des = string;
/* 28:   */   }
/* 29:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.parametros.model.PartesCuerpo
 * JD-Core Version:    0.7.0.1
 */