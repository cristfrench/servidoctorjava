/*  1:   */ package com.servidoctor.sdfamily.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class ElementoConsumoUsuario
/*  6:   */ {
/*  7:   */   private BigDecimal econu_cod;
/*  8:   */   private BigDecimal econu_usuf_cod;
/*  9:   */   private BigDecimal econu_econ_cod;
/* 10:   */   private BigDecimal econu_cons_cod;
/* 11:   */   
/* 12:   */   public BigDecimal getEconu_cod()
/* 13:   */   {
/* 14:19 */     return this.econu_cod;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public BigDecimal getEconu_cons_cod()
/* 18:   */   {
/* 19:22 */     return this.econu_cons_cod;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public BigDecimal getEconu_econ_cod()
/* 23:   */   {
/* 24:25 */     return this.econu_econ_cod;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public BigDecimal getEconu_usuf_cod()
/* 28:   */   {
/* 29:28 */     return this.econu_usuf_cod;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void setEconu_cod(BigDecimal econu_cod)
/* 33:   */   {
/* 34:31 */     this.econu_cod = econu_cod;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void setEconu_cons_cod(BigDecimal econu_cons_cod)
/* 38:   */   {
/* 39:34 */     this.econu_cons_cod = econu_cons_cod;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void setEconu_econ_cod(BigDecimal econu_econ_cod)
/* 43:   */   {
/* 44:37 */     this.econu_econ_cod = econu_econ_cod;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void setEconu_usuf_cod(BigDecimal econu_usuf_cod)
/* 48:   */   {
/* 49:40 */     this.econu_usuf_cod = econu_usuf_cod;
/* 50:   */   }
/* 51:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.sdfamily.model.ElementoConsumoUsuario
 * JD-Core Version:    0.7.0.1
 */