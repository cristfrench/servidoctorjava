/*  1:   */ package com.servidoctor.sdfamily.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class GinecologiaOperacionesUsuario
/*  6:   */ {
/*  7:   */   private BigDecimal gopeu_cod;
/*  8:   */   private BigDecimal gopeu_usuf_cod;
/*  9:   */   private BigDecimal gopeu_gope_cod;
/* 10:   */   private BigDecimal gopeu_fecha;
/* 11:   */   private BigDecimal gopeu_cantidad;
/* 12:   */   private String gopeu_des;
/* 13:   */   
/* 14:   */   public BigDecimal getGopeu_cantidad()
/* 15:   */   {
/* 16:21 */     return this.gopeu_cantidad;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public BigDecimal getGopeu_cod()
/* 20:   */   {
/* 21:24 */     return this.gopeu_cod;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String getGopeu_des()
/* 25:   */   {
/* 26:27 */     return this.gopeu_des;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public BigDecimal getGopeu_fecha()
/* 30:   */   {
/* 31:30 */     return this.gopeu_fecha;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public BigDecimal getGopeu_gope_cod()
/* 35:   */   {
/* 36:33 */     return this.gopeu_gope_cod;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public BigDecimal getGopeu_usuf_cod()
/* 40:   */   {
/* 41:36 */     return this.gopeu_usuf_cod;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public void setGopeu_cantidad(BigDecimal gopeu_cantidad)
/* 45:   */   {
/* 46:39 */     this.gopeu_cantidad = gopeu_cantidad;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void setGopeu_cod(BigDecimal gopeu_cod)
/* 50:   */   {
/* 51:42 */     this.gopeu_cod = gopeu_cod;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public void setGopeu_des(String gopeu_des)
/* 55:   */   {
/* 56:45 */     this.gopeu_des = gopeu_des;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public void setGopeu_fecha(BigDecimal gopeu_fecha)
/* 60:   */   {
/* 61:48 */     this.gopeu_fecha = gopeu_fecha;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public void setGopeu_gope_cod(BigDecimal gopeu_gope_cod)
/* 65:   */   {
/* 66:51 */     this.gopeu_gope_cod = gopeu_gope_cod;
/* 67:   */   }
/* 68:   */   
/* 69:   */   public void setGopeu_usuf_cod(BigDecimal gopeu_usuf_cod)
/* 70:   */   {
/* 71:54 */     this.gopeu_usuf_cod = gopeu_usuf_cod;
/* 72:   */   }
/* 73:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.sdfamily.model.GinecologiaOperacionesUsuario
 * JD-Core Version:    0.7.0.1
 */