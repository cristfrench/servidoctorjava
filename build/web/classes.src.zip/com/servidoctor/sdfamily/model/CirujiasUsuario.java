/*  1:   */ package com.servidoctor.sdfamily.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class CirujiasUsuario
/*  6:   */ {
/*  7:   */   private BigDecimal ciru_cod;
/*  8:   */   private BigDecimal ciru_usuf_cod;
/*  9:   */   private BigDecimal ciru_cir_cod;
/* 10:   */   private String ciru_des;
/* 11:   */   private BigDecimal ciru_anio;
/* 12:   */   
/* 13:   */   public BigDecimal getCiru_anio()
/* 14:   */   {
/* 15:20 */     return this.ciru_anio;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public BigDecimal getCiru_cir_cod()
/* 19:   */   {
/* 20:23 */     return this.ciru_cir_cod;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public BigDecimal getCiru_cod()
/* 24:   */   {
/* 25:26 */     return this.ciru_cod;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public String getCiru_des()
/* 29:   */   {
/* 30:29 */     return this.ciru_des;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public BigDecimal getCiru_usuf_cod()
/* 34:   */   {
/* 35:32 */     return this.ciru_usuf_cod;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void setCiru_anio(BigDecimal ciru_anio)
/* 39:   */   {
/* 40:35 */     this.ciru_anio = ciru_anio;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public void setCiru_cir_cod(BigDecimal ciru_cir_cod)
/* 44:   */   {
/* 45:38 */     this.ciru_cir_cod = ciru_cir_cod;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void setCiru_cod(BigDecimal ciru_cod)
/* 49:   */   {
/* 50:41 */     this.ciru_cod = ciru_cod;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public void setCiru_des(String ciru_des)
/* 54:   */   {
/* 55:44 */     this.ciru_des = ciru_des;
/* 56:   */   }
/* 57:   */   
/* 58:   */   public void setCiru_usuf_cod(BigDecimal ciru_usuf_cod)
/* 59:   */   {
/* 60:47 */     this.ciru_usuf_cod = ciru_usuf_cod;
/* 61:   */   }
/* 62:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.sdfamily.model.CirujiasUsuario
 * JD-Core Version:    0.7.0.1
 */