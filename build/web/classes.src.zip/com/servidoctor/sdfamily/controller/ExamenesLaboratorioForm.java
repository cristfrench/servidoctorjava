/*   1:    */ package com.servidoctor.sdfamily.controller;
/*   2:    */ 
/*   3:    */ import org.apache.struts.validator.ValidatorForm;
/*   4:    */ 
/*   5:    */ public class ExamenesLaboratorioForm
/*   6:    */   extends ValidatorForm
/*   7:    */ {
/*   8: 12 */   String elab_cod = "0";
/*   9: 13 */   String elab_usu_cod = "0";
/*  10: 14 */   String elab_des = "";
/*  11: 15 */   String elab_fecha1 = "0";
/*  12: 16 */   String elab_resultado1 = "0";
/*  13: 17 */   String elab_fecha2 = "0";
/*  14: 18 */   String elab_resultado2 = "0";
/*  15: 19 */   String elab_fecha3 = "0";
/*  16: 20 */   String elab_resultado3 = "0";
/*  17:    */   
/*  18:    */   public String getElab_cod()
/*  19:    */   {
/*  20: 28 */     return this.elab_cod;
/*  21:    */   }
/*  22:    */   
/*  23:    */   public String getElab_des()
/*  24:    */   {
/*  25: 35 */     return this.elab_des;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public String getElab_fecha1()
/*  29:    */   {
/*  30: 42 */     return this.elab_fecha1;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public String getElab_fecha2()
/*  34:    */   {
/*  35: 49 */     return this.elab_fecha2;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public String getElab_fecha3()
/*  39:    */   {
/*  40: 56 */     return this.elab_fecha3;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public String getElab_resultado1()
/*  44:    */   {
/*  45: 63 */     return this.elab_resultado1;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public String getElab_resultado2()
/*  49:    */   {
/*  50: 70 */     return this.elab_resultado2;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public String getElab_resultado3()
/*  54:    */   {
/*  55: 77 */     return this.elab_resultado3;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public String getElab_usu_cod()
/*  59:    */   {
/*  60: 84 */     return this.elab_usu_cod;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void setElab_cod(String string)
/*  64:    */   {
/*  65: 91 */     this.elab_cod = string;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void setElab_des(String string)
/*  69:    */   {
/*  70: 98 */     this.elab_des = string;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void setElab_fecha1(String string)
/*  74:    */   {
/*  75:105 */     this.elab_fecha1 = string;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void setElab_fecha2(String string)
/*  79:    */   {
/*  80:112 */     this.elab_fecha2 = string;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void setElab_fecha3(String string)
/*  84:    */   {
/*  85:119 */     this.elab_fecha3 = string;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void setElab_resultado1(String string)
/*  89:    */   {
/*  90:126 */     this.elab_resultado1 = string;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void setElab_resultado2(String string)
/*  94:    */   {
/*  95:133 */     this.elab_resultado2 = string;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void setElab_resultado3(String string)
/*  99:    */   {
/* 100:140 */     this.elab_resultado3 = string;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public void setElab_usu_cod(String string)
/* 104:    */   {
/* 105:147 */     this.elab_usu_cod = string;
/* 106:    */   }
/* 107:    */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.sdfamily.controller.ExamenesLaboratorioForm
 * JD-Core Version:    0.7.0.1
 */