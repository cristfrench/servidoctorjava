package com.servidoctor.sdfamily.controller;

import org.apache.struts.validator.ValidatorForm;

public class MedicinaCompletoForm
  extends ValidatorForm
{}


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.sdfamily.controller.MedicinaCompletoForm
 * JD-Core Version:    0.7.0.1
 */