/*  1:   */ package com.servidoctor.sdcars.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class GruposVehiculo
/*  6:   */ {
/*  7:   */   private BigDecimal grupv_cod;
/*  8:   */   private BigDecimal grupv_vehi_cod;
/*  9:   */   private BigDecimal grupv_grup_cod;
/* 10:   */   private BigDecimal grupv_dias_antes;
/* 11:   */   
/* 12:   */   public BigDecimal getGrupv_cod()
/* 13:   */   {
/* 14:19 */     return this.grupv_cod;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public BigDecimal getGrupv_dias_antes()
/* 18:   */   {
/* 19:22 */     return this.grupv_dias_antes;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public BigDecimal getGrupv_grup_cod()
/* 23:   */   {
/* 24:25 */     return this.grupv_grup_cod;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public BigDecimal getGrupv_vehi_cod()
/* 28:   */   {
/* 29:28 */     return this.grupv_vehi_cod;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void setGrupv_cod(BigDecimal grupv_cod)
/* 33:   */   {
/* 34:31 */     this.grupv_cod = grupv_cod;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void setGrupv_dias_antes(BigDecimal grupv_dias_antes)
/* 38:   */   {
/* 39:34 */     this.grupv_dias_antes = grupv_dias_antes;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void setGrupv_grup_cod(BigDecimal grupv_grup_cod)
/* 43:   */   {
/* 44:37 */     this.grupv_grup_cod = grupv_grup_cod;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void setGrupv_vehi_cod(BigDecimal grupv_vehi_cod)
/* 48:   */   {
/* 49:40 */     this.grupv_vehi_cod = grupv_vehi_cod;
/* 50:   */   }
/* 51:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.sdcars.model.GruposVehiculo
 * JD-Core Version:    0.7.0.1
 */