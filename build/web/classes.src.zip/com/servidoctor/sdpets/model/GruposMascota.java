/*  1:   */ package com.servidoctor.sdpets.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class GruposMascota
/*  6:   */ {
/*  7:   */   private BigDecimal grupm_cod;
/*  8:   */   private BigDecimal grupm_mas_cod;
/*  9:   */   private BigDecimal grupm_grup_cod;
/* 10:   */   private BigDecimal grupm_dias_antes;
/* 11:   */   
/* 12:   */   public BigDecimal getGrupm_cod()
/* 13:   */   {
/* 14:19 */     return this.grupm_cod;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public BigDecimal getGrupm_dias_antes()
/* 18:   */   {
/* 19:23 */     return this.grupm_dias_antes;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public BigDecimal getGrupm_grup_cod()
/* 23:   */   {
/* 24:27 */     return this.grupm_grup_cod;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public BigDecimal getGrupm_mas_cod()
/* 28:   */   {
/* 29:31 */     return this.grupm_mas_cod;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void setGrupm_cod(BigDecimal decimal)
/* 33:   */   {
/* 34:35 */     this.grupm_cod = decimal;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void setGrupm_dias_antes(BigDecimal decimal)
/* 38:   */   {
/* 39:39 */     this.grupm_dias_antes = decimal;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void setGrupm_grup_cod(BigDecimal decimal)
/* 43:   */   {
/* 44:43 */     this.grupm_grup_cod = decimal;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void setGrupm_mas_cod(BigDecimal decimal)
/* 48:   */   {
/* 49:47 */     this.grupm_mas_cod = decimal;
/* 50:   */   }
/* 51:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.sdpets.model.GruposMascota
 * JD-Core Version:    0.7.0.1
 */