/*  1:   */ package com.servidoctor.parametros.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class GastosAnuales
/*  6:   */ {
/*  7:   */   private BigDecimal gas_cod;
/*  8:   */   private String gas_descripcion;
/*  9:   */   
/* 10:   */   public BigDecimal getGas_cod()
/* 11:   */   {
/* 12:17 */     return this.gas_cod;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public void setGas_cod(BigDecimal gas_cod)
/* 16:   */   {
/* 17:21 */     this.gas_cod = gas_cod;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public String getGas_descripcion()
/* 21:   */   {
/* 22:25 */     return this.gas_descripcion;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setGas_descripcion(String gas_descripcion)
/* 26:   */   {
/* 27:29 */     this.gas_descripcion = gas_descripcion;
/* 28:   */   }
/* 29:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.parametros.model.GastosAnuales
 * JD-Core Version:    0.7.0.1
 */