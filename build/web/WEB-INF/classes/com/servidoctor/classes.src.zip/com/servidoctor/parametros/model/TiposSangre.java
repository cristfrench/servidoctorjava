/*  1:   */ package com.servidoctor.parametros.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class TiposSangre
/*  6:   */ {
/*  7:   */   private BigDecimal tipsan_cod;
/*  8:   */   private String tipsan_des;
/*  9:   */   
/* 10:   */   public BigDecimal getTipsan_cod()
/* 11:   */   {
/* 12:17 */     return this.tipsan_cod;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public String getTipsan_des()
/* 16:   */   {
/* 17:21 */     return this.tipsan_des;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setTipsan_cod(BigDecimal decimal)
/* 21:   */   {
/* 22:25 */     this.tipsan_cod = decimal;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setTipsan_des(String string)
/* 26:   */   {
/* 27:29 */     this.tipsan_des = string;
/* 28:   */   }
/* 29:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.parametros.model.TiposSangre
 * JD-Core Version:    0.7.0.1
 */