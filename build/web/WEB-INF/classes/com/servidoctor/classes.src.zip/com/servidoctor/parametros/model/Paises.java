/*  1:   */ package com.servidoctor.parametros.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class Paises
/*  6:   */ {
/*  7:   */   private BigDecimal pais_cod;
/*  8:   */   private String pais_des;
/*  9:   */   
/* 10:   */   public BigDecimal getPais_cod()
/* 11:   */   {
/* 12:19 */     return this.pais_cod;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public String getPais_des()
/* 16:   */   {
/* 17:23 */     return this.pais_des;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setPais_cod(BigDecimal decimal)
/* 21:   */   {
/* 22:27 */     this.pais_cod = decimal;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setPais_des(String string)
/* 26:   */   {
/* 27:31 */     this.pais_des = string;
/* 28:   */   }
/* 29:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.parametros.model.Paises
 * JD-Core Version:    0.7.0.1
 */