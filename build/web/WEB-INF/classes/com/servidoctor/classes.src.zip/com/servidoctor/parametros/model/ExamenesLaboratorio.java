/*   1:    */ package com.servidoctor.parametros.model;
/*   2:    */ 
/*   3:    */ import java.math.BigDecimal;
/*   4:    */ 
/*   5:    */ public class ExamenesLaboratorio
/*   6:    */ {
/*   7: 19 */   BigDecimal elab_cod = new BigDecimal("0");
/*   8: 20 */   BigDecimal elab_usuf_cod = new BigDecimal("0");
/*   9: 21 */   String elab_des = "";
/*  10: 22 */   BigDecimal elab_fecha1 = new BigDecimal("0");
/*  11: 23 */   BigDecimal elab_resultado1 = new BigDecimal("0");
/*  12: 24 */   BigDecimal elab_fecha2 = new BigDecimal("0");
/*  13: 25 */   BigDecimal elab_resultado2 = new BigDecimal("0");
/*  14: 26 */   BigDecimal elab_fecha3 = new BigDecimal("0");
/*  15: 27 */   BigDecimal elab_resultado3 = new BigDecimal("0");
/*  16:    */   
/*  17:    */   public BigDecimal getElab_cod()
/*  18:    */   {
/*  19: 33 */     return this.elab_cod;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public String getElab_des()
/*  23:    */   {
/*  24: 40 */     return this.elab_des;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public BigDecimal getElab_fecha1()
/*  28:    */   {
/*  29: 47 */     return this.elab_fecha1;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public BigDecimal getElab_fecha2()
/*  33:    */   {
/*  34: 54 */     return this.elab_fecha2;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public BigDecimal getElab_fecha3()
/*  38:    */   {
/*  39: 61 */     return this.elab_fecha3;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public BigDecimal getElab_resultado1()
/*  43:    */   {
/*  44: 68 */     return this.elab_resultado1;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public BigDecimal getElab_resultado2()
/*  48:    */   {
/*  49: 75 */     return this.elab_resultado2;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public BigDecimal getElab_resultado3()
/*  53:    */   {
/*  54: 82 */     return this.elab_resultado3;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void setElab_cod(BigDecimal decimal)
/*  58:    */   {
/*  59: 89 */     this.elab_cod = decimal;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setElab_des(String string)
/*  63:    */   {
/*  64: 96 */     this.elab_des = string;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void setElab_fecha1(BigDecimal decimal)
/*  68:    */   {
/*  69:103 */     this.elab_fecha1 = decimal;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setElab_fecha2(BigDecimal decimal)
/*  73:    */   {
/*  74:110 */     this.elab_fecha2 = decimal;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public void setElab_fecha3(BigDecimal decimal)
/*  78:    */   {
/*  79:117 */     this.elab_fecha3 = decimal;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void setElab_resultado1(BigDecimal decimal)
/*  83:    */   {
/*  84:124 */     this.elab_resultado1 = decimal;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void setElab_resultado2(BigDecimal decimal)
/*  88:    */   {
/*  89:131 */     this.elab_resultado2 = decimal;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void setElab_resultado3(BigDecimal decimal)
/*  93:    */   {
/*  94:138 */     this.elab_resultado3 = decimal;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public BigDecimal getElab_usuf_cod()
/*  98:    */   {
/*  99:145 */     return this.elab_usuf_cod;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public void setElab_usuf_cod(BigDecimal decimal)
/* 103:    */   {
/* 104:152 */     this.elab_usuf_cod = decimal;
/* 105:    */   }
/* 106:    */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.parametros.model.ExamenesLaboratorio
 * JD-Core Version:    0.7.0.1
 */