/*  1:   */ package com.servidoctor.sdpets.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class AlergiasPets
/*  6:   */ {
/*  7:   */   private BigDecimal alep_cod;
/*  8:   */   private BigDecimal alep_mas_cod;
/*  9:   */   private String alep_des;
/* 10:   */   private BigDecimal alep_anio_desde;
/* 11:   */   private String alep_novedad;
/* 12:   */   
/* 13:   */   public BigDecimal getAlep_anio_desde()
/* 14:   */   {
/* 15:20 */     return this.alep_anio_desde;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public BigDecimal getAlep_cod()
/* 19:   */   {
/* 20:23 */     return this.alep_cod;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String getAlep_des()
/* 24:   */   {
/* 25:26 */     return this.alep_des;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public String getAlep_novedad()
/* 29:   */   {
/* 30:29 */     return this.alep_novedad;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public BigDecimal getAlep_mas_cod()
/* 34:   */   {
/* 35:32 */     return this.alep_mas_cod;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void setAlep_anio_desde(BigDecimal alep_anio_desde)
/* 39:   */   {
/* 40:35 */     this.alep_anio_desde = alep_anio_desde;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public void setAlep_cod(BigDecimal alep_cod)
/* 44:   */   {
/* 45:38 */     this.alep_cod = alep_cod;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void setAlep_des(String alep_des)
/* 49:   */   {
/* 50:41 */     this.alep_des = alep_des;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public void setAlep_novedad(String alep_novedad)
/* 54:   */   {
/* 55:44 */     this.alep_novedad = alep_novedad;
/* 56:   */   }
/* 57:   */   
/* 58:   */   public void setAlep_mas_cod(BigDecimal alep_mas_cod)
/* 59:   */   {
/* 60:47 */     this.alep_mas_cod = alep_mas_cod;
/* 61:   */   }
/* 62:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.sdpets.model.AlergiasPets
 * JD-Core Version:    0.7.0.1
 */