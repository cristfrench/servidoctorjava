package com.servidoctor.util.classes;

public class CookieKeys
{
  public static final String GUEST_LANGUAGE_ID = "GUEST_LANGUAGE_ID";
  public static final String ID = "ID";
  public static final String LOGIN = "LOGIN";
  public static final String PASSWORD = "PASSWORD";
  public static final int MAX_AGE = 31536000;
}


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.util.classes.CookieKeys
 * JD-Core Version:    0.7.0.1
 */