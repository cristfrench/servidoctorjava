/*  1:   */ package com.servidoctor.sdpets.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class CirugiasPets
/*  6:   */ {
/*  7:   */   private BigDecimal cirp_cod;
/*  8:   */   private BigDecimal cirp_mas_cod;
/*  9:   */   private String cirp_des;
/* 10:   */   private BigDecimal cirp_anio;
/* 11:   */   
/* 12:   */   public BigDecimal getCirp_anio()
/* 13:   */   {
/* 14:19 */     return this.cirp_anio;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public BigDecimal getCirp_cod()
/* 18:   */   {
/* 19:22 */     return this.cirp_cod;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String getCirp_des()
/* 23:   */   {
/* 24:25 */     return this.cirp_des;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public BigDecimal getCirp_mas_cod()
/* 28:   */   {
/* 29:28 */     return this.cirp_mas_cod;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void setCirp_anio(BigDecimal cirp_anio)
/* 33:   */   {
/* 34:31 */     this.cirp_anio = cirp_anio;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void setCirp_cod(BigDecimal cirp_cod)
/* 38:   */   {
/* 39:34 */     this.cirp_cod = cirp_cod;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void setCirp_des(String cirp_des)
/* 43:   */   {
/* 44:37 */     this.cirp_des = cirp_des;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void setCirp_mas_cod(BigDecimal cirp_mas_cod)
/* 48:   */   {
/* 49:40 */     this.cirp_mas_cod = cirp_mas_cod;
/* 50:   */   }
/* 51:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.sdpets.model.CirugiasPets
 * JD-Core Version:    0.7.0.1
 */