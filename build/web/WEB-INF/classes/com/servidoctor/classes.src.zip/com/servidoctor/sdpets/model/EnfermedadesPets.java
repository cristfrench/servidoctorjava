/*  1:   */ package com.servidoctor.sdpets.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class EnfermedadesPets
/*  6:   */ {
/*  7:   */   private BigDecimal enfp_cod;
/*  8:   */   private String enfp_des;
/*  9:   */   private BigDecimal enfp_mas_cod;
/* 10:   */   private BigDecimal enfp_anio_desde;
/* 11:   */   private String enfp_novedad;
/* 12:   */   
/* 13:   */   public BigDecimal getEnfp_cod()
/* 14:   */   {
/* 15:21 */     return this.enfp_cod;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void setEnfp_cod(BigDecimal enfpCod)
/* 19:   */   {
/* 20:24 */     this.enfp_cod = enfpCod;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String getEnfp_des()
/* 24:   */   {
/* 25:27 */     return this.enfp_des;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void setEnfp_des(String enfpDes)
/* 29:   */   {
/* 30:30 */     this.enfp_des = enfpDes;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public BigDecimal getEnfp_mas_cod()
/* 34:   */   {
/* 35:33 */     return this.enfp_mas_cod;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void setEnfp_mas_cod(BigDecimal enfpMasCod)
/* 39:   */   {
/* 40:36 */     this.enfp_mas_cod = enfpMasCod;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public BigDecimal getEnfp_anio_desde()
/* 44:   */   {
/* 45:39 */     return this.enfp_anio_desde;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void setEnfp_anio_desde(BigDecimal enfpAnioDesde)
/* 49:   */   {
/* 50:42 */     this.enfp_anio_desde = enfpAnioDesde;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public String getEnfp_novedad()
/* 54:   */   {
/* 55:45 */     return this.enfp_novedad;
/* 56:   */   }
/* 57:   */   
/* 58:   */   public void setEnfp_novedad(String enfpNovedad)
/* 59:   */   {
/* 60:48 */     this.enfp_novedad = enfpNovedad;
/* 61:   */   }
/* 62:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.sdpets.model.EnfermedadesPets
 * JD-Core Version:    0.7.0.1
 */