/*  1:   */ package com.servidoctor.parametros.model;
/*  2:   */ 
/*  3:   */ import java.math.BigDecimal;
/*  4:   */ 
/*  5:   */ public class ElementoConsumo
/*  6:   */ {
/*  7:   */   private BigDecimal econ_cod;
/*  8:   */   private String econ_des;
/*  9:   */   
/* 10:   */   public BigDecimal getEcon_cod()
/* 11:   */   {
/* 12:17 */     return this.econ_cod;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public String getEcon_des()
/* 16:   */   {
/* 17:21 */     return this.econ_des;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setEcon_cod(BigDecimal decimal)
/* 21:   */   {
/* 22:25 */     this.econ_cod = decimal;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setEcon_des(String string)
/* 26:   */   {
/* 27:29 */     this.econ_des = string;
/* 28:   */   }
/* 29:   */ }


/* Location:           Z:\Proyectos_2017\colombia\ServiDoctor\WEB-INF\classes\
 * Qualified Name:     com.servidoctor.parametros.model.ElementoConsumo
 * JD-Core Version:    0.7.0.1
 */